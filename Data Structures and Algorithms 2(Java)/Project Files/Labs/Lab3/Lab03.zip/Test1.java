// A sample use of the Box1 class.
public class Test1 {
  public static void main(String argv[]) {
    Box1 x = new Box1();
    x.setA(23);
    System.out.println(x.getA());
    Box1 y = new Box1();
  }
}
